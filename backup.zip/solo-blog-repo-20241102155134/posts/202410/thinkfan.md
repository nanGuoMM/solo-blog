title: thinkfan
date: '2024-10-09 21:51:04'
updated: '2024-11-02 14:35:28'
tags: [linux]
permalink: /articles/2024/10/09/1728481864100.html
---
## 安装

`sudo pacman -S thinkfan`

## 设置风扇组件

* 编辑
  `sudo vim /etc/modprobe.d/99-thinkfan.conf`
* 输入以下内容
  `options thinkpad_acpi fan_control=1`
* 再加载模块
  `modprobe thinkpad_acpi`
* 查找thinkfan所需的几个标准文件
  `find /sys/devices -type f -name "temp*_input"`

## 配置

`sudo vim /etc/thinkfan.yaml`

## 配置文件

`https://raw.githubusercontent.com/nanGuoMM/config/refs/heads/master/thinkfan.yaml`

该配置只适用于thinkpad x280，其他机型将hwmon后面的路径以find的结果替换

## 运行

* 执行
  `sudo thinkfan -n`
* 若没报错
  `sudo systemctl enable --now thinkfan`

  ![image.png](https://b3logfile.com/file/2024/10/image-NdQ8CBy.png)
