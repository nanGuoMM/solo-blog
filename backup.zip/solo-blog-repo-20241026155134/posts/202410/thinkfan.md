title: thinkfan
date: '2024-10-09 21:51:04'
updated: '2024-10-14 11:52:40'
tags: [linux]
permalink: /articles/2024/10/09/1728481864100.html
---
## 安装

`sudo pacman -S thinkfan`

## 设置风扇组件

* 编辑
  `sudo vim /etc/modprobe.d/99-thinkfan.conf`
* 输入以下内容
  `options thinkpad_acpi fan_control=1`
* 再加载模块
  `modprobe thinkpad_acpi`
* 查找thinkfan所需的几个标准文件
  `find /sys/devices -type f -name "temp*_input"`

## 配置

`sudo vim /etc/thinkfan.yaml`

## 配置文件

```yaml
sensors: 
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp6_input
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp3_input
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp7_input
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp4_input
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp8_input
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp1_input
    - hwmon: /sys/devices/platform/thinkpad_hwmon/hwmon/hwmon3/temp5_input
    - hwmon: /sys/devices/virtual/thermal/thermal_zone0/hwmon1/temp1_input
    - hwmon: /sys/devices/virtual/thermal/thermal_zone3/hwmon4/temp1_input
fans:
  - tpacpi: /proc/acpi/ibm/fan
levels:
  - [0, 0, 45]               # 在45°C以下风扇关闭
  - [1, 45, 55]   # 温度在45°C到55°C之间，风扇自动调节
  - [2, 55, 65]      # 温度在55°C到65°C之间，风扇运行在1级速度
  - [3, 65, 75]      # 温度在65°C到75°C之间，风扇运行在2级速度
  - [4, 75, 85]      # 温度在75°C到85°C之间，风扇运行在3级速度
  - [5, 85, 255]  # 温度超过85°C，风扇全速运行
```

该配置只适用于thinkpad x280，其他机型将hwmon后面的路径以find的结果替换

## 运行

* 执行
  `sudo thinkfan -n`
* 若没报错
  `sudo systemctl enable --now thinkfan`

  ![image.png](https://b3logfile.com/file/2024/10/image-NdQ8CBy.png)
