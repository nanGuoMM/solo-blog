title: rsg安装和配置
date: '2024-10-09 20:13:57'
updated: '2024-10-09 21:43:12'
tags: [linux]
permalink: /articles/2024/10/09/1728476037201.html
---
## 安装

* 执行

`curl -s https://raw.githubusercontent.com/huahuadeliaoliao/RoseSong/main/installation_script/install_rosesong.sh | bash`

* Arch用户要额外安装两个包

```
sudo pacman -S gst-plugins-good
paru -S gst-plugins-intel-msdk-git
```

## 设置环境变量

`export PATH=$PATH:~/.local/bin`
