title: maim安装与配置
date: '2024-10-09 23:58:37'
updated: '2024-10-09 23:59:01'
tags: [linux]
permalink: /articles/2024/10/09/1728489517372.html
---
## 安装

`sudo pacman -S maim xclip`

其中xclip配合使用可以实现将截图复制到剪切板

## 使用

* 在~目录下创建目录结构
  `mkdir -p ~/Pictures/screenshots`
* 使用的语句，可以alias设置别名，也可以做其他操作

`maim -s -u | tee ~/Pictures/screenshots/$(date +'%Y-%m-%d-%H-%M-%S').png | xclip -selection clipboard -t image/png -i`

![image.png](https://b3logfile.com/file/2024/10/image-qO5cjHh.png)
