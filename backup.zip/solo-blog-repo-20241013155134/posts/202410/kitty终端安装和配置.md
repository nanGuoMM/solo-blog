title: kitty终端安装和配置
date: '2024-10-10 00:15:07'
updated: '2024-10-10 21:24:28'
tags: [linux]
permalink: /articles/2024/10/10/1728490507178.html
---
## 安装

`sudo pacman -S kitty`

## 配置

* 执行以设置主题
  `kitty +kitten themes`
* 编辑
  `vim .config/kitty/kitty.conf`

内容

```
# BEGIN_KITTY_THEME
# Base4Tone_Modern_W Dark
include current-theme.conf
# END_KITTY_THEME


# font
font_size 14

# BEGIN_KITTY_FONTS
font_family      family="JetBrainsMono Nerd Font"
bold_font        auto
italic_font      auto
bold_italic_font auto
# END_KITTY_FONTS

background_opacity 0.9
background_image none
enable_audio_bell no
```

![image.png](https://b3logfile.com/file/2024/10/image-vUCmPjd.png)

## 我用的主题

* 新建current-theme.conf文件

`vim .config/kitty/current-theme.conf`

* 输入保存并退出

```conf
# vim:ft=kitty

## name: Base4Tone_Modern_W Dark
## author: Bram de Haan (https://github.com/atelierbram)
## license: MIT
## upstream: https://github.com/atelierbram/Base4Tone-kitty/blob/main/themes/base4tone-modern-w-dark.conf
## blurb: theme with limited color palette


#: The basic colors

foreground #ede8ea
background #201d1e
selection_foreground #ede8ea
selection_background #161314


#: Cursor colors

cursor #6a878a
cursor_text_color #201d1e


#: URL underline color when hovering with mouse

url_color #dd407c


#: kitty window border colors and terminal bell colors

active_border_color #a4e6ef
inactive_border_color #201d1e
bell_border_color #de5745
visual_bell_color none


#: OS Window titlebar colors

wayland_titlebar_color #2b2728
macos_titlebar_color #2b2728


#: Tab bar colors

active_tab_foreground #ede8ea
active_tab_background #201d1e
inactive_tab_foreground #817479
inactive_tab_background #363032
tab_bar_background #363032
tab_bar_margin_color none


#: Colors for marks (marked text in the terminal)

mark1_foreground #070d0d
mark1_background #1398aa
mark2_foreground #0d080a
mark2_background #dd407c
mark3_foreground #0d0807
mark3_background #de5745


#: The basic 16 colors

#: black
color0 #201d1e
color8 #0d080a

#: red
color1 #21a00d
color9 #39c723

#: green
color2 #1398aa
color10 #5ad2e2

#: yellow
color3 #3ccadd
color11 #a4e6ef

#: blue
color4 #eb75a2
color12 #f8bfd5

#: magenta
color5 #e97263
color13 #f18c7e

#: cyan
color6 #23b4c7
color14 #f6b1cc

#: white
color7 #ede8ea
color15 #f9f6f7

```
