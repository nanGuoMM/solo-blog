title: redshift安装和配置
date: '2024-10-09 19:28:49'
updated: '2024-10-09 21:38:09'
tags: [linux]
permalink: /articles/2024/10/09/1728473329659.html
---
## 安装

`sudo pacman -S redshift`

## 配置

* 编辑`sudo vim /etc/redshift.conf`
* 输入

```conf
[redshift]
; 设置色温
temp-day=5500
temp-night=3500

; 渐进地改变色温
transition=1

adjustment-method=randr

; 手工指定经纬度
location-provider=manual

[manual]
lat=23.12
lon=113.25

```

## 运行

`redshift &`
