title: vim
date: '2024-10-09 19:00:27'
updated: '2024-10-14 11:53:04'
tags: [linux]
permalink: /articles/2024/10/09/1728471627388.html
---
![image.png](https://b3logfile.com/file/2024/10/image-LMIpSpZ.png)

## 安装vim-plug

`curl -fLo ~/.vim/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim`

## 安装nodejs npm

`pacman -S nodejs npm`

## 配置文件

```js
" === 插件管理 ===
call plug#begin()

" 状态行插件
Plug 'vim-airline/vim-airline'

" 彩虹括号
Plug 'frazrepo/vim-rainbow'

" 主题
Plug 'morhetz/gruvbox'

" 快速跳转
Plug 'easymotion/vim-easymotion'

" markdown
Plug 'iamcco/markdown-preview.nvim', { 'do': 'cd app && npx --yes yarn install' }

call plug#end()

" === 主题设置 ===
if has("termguicolors")
    set termguicolors
endif

" 主题配色方案
colorscheme gruvbox
set bg=dark

" === 基本编辑器设置 ===
set laststatus=2
set scrolloff=10  " 提高 scrolloff，避免光标过于贴近边界
set encoding=utf-8
syntax on
syntax enable
set tabstop=2
set shiftwidth=2
set softtabstop=2
set number
set relativenumber
set foldmethod=indent
set showcmd
set hlsearch
set incsearch
set wildmenu
set clipboard=unnamedplus
set undofile  " 启用撤销文件
set autoindent  " 自动缩进
set smartindent " 智能缩进
set backspace=indent,eol,start
au BufReadPost * if line("'\"") > 1 && line("'\"") <= line("$") | exe "normal! g'\"" | endif

" 保存时自动删除尾部空格
autocmd BufWritePre * :%s/\s\+$//e

" === 文件类型设置 ===
filetype indent on

" === 键映射 ===
inoremap jk <Esc>

let mapleader = " "  " 设置 leader 键为 空格
map <leader>q :q<CR>
map <leader>wq :wq<CR>

" 分屏
map <leader>sl :set splitright<CR>:vsplit<CR>
map <leader>sh :set nosplitright<CR>:vsplit<CR>
map <leader>sk :set nosplitbelow<CR>:split<CR>
map <leader>sj :set splitbelow<CR>:split<CR>

map <up> :res +5<CR>
map <down> :res -5<CR>
map <left> :vertical resize-5<CR>
map <right> :vertical resize+5<CR>


" === 特殊功能 ===
let g:rainbow_active = 1  " 启用彩虹括号
let g:airline_theme = 'gruvbox'  " 设置 vim-airline 的主题
let g:airline_powerline_fonts=1
let g:airline#extensions#tabline#enabled = 1

" Easymotion 快速跳转配置
let g:EasyMotion_smartcase = 1
"map <Leader>h <Plug>(easymotion-linebackward)
"map <Leader>j <Plug>(easymotion-j)
"map <Leader>k <Plug>(easymotion-k)
"map <Leader>l <Plug>(easymotion-lineforward)
"map <Leader>. <Plug>(easymotion-repeat)
nmap <Leader>f <Plug>(easymotion-overwin-f)

```

最在vim命令模式执行PlugInstall
