title: solo博客搭建全过程
date: '2024-10-07 15:45:44'
updated: '2024-10-07 15:47:21'
tags: [Solo]
permalink: /articles/2024/10/07/1728287144528.html
---
## 使用docker部署到云服务器的方法搭建的博客

![202410071437.png](https://b3logfile.com/file/2024/10/2024-10-07_14-37-AhKbzpp.png)

## 拉取mysql，nginx，solo镜像

`docker pull mysql nginx b3log/solo`

## 编写mysql，nginx的docker-compose.yml

因为我mysql和nginx还有其他用途，所以额外部署，根据实际环境而定

~~~yml
version: '3.8'

services:
  mysql:
    image: mysql:latest
    restart: always
    container_name: mysql
    environment:
      MYSQL_ROOT_PASSWORD: ${PASSWD}
    ports:
      - "3306:3306"
    volumes:
      - ./mysql/data:/var/lib/mysql
      - ./mysql/conf:/etc/mysql/conf.d
    networks:
      - nanguo_net

  nginx:
    image: nginx:latest
    restart: always
    container_name: nginx
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx/conf:/etc/nginx
    networks:
      - nanguo_net

networks:
  nanguo_net:
    driver: bridge

~~~

说明:

* ${PASSWD}需自行配置数据库密码

初始化需要的数据卷文件(在docker-compose.yml文件夹下)，编写init.sh脚本并执行

```bash
#!/bin/bash

# 创建 mysql 数据卷和配置文件夹
mkdir -p ./mysql/data
mkdir -p ./mysql/conf

# 创建 nginx 配置文件夹和网页文件夹
mkdir -p ./nginx/conf
mkdir -p ./nginx/html

echo "所需的文件夹已成功创建！"
```

在docker-compose.yml目录下执行`docker-compose up -d`部署mysql和nginx容器

## 配置nginx

* 在docker-compose执行`cd nginx/conf/ `移动到nginx配置目录
* 将网站的ssl证书复制到此目录命名为certs
* 编辑nginx.conf文件

  ```conf
  worker_processes  1;

  events {
      worker_connections  1024;
  }

  http {
      include       mime.types;
      default_type  application/octet-stream;

      sendfile        on;
      keepalive_timeout  65;

      include /etc/nginx/conf.d/*.conf;
  }
  ```
* 编辑conf.d/default.conf文件

  ```conf
  server {
      listen 80;
      server_name nanguomm.top;
      return 301 https://$host$request_uri;
  }

  server {
      listen 443 ssl;
      server_name nanguomm.top;

      ssl_certificate  /etc/nginx/certs/full_chain.pem;
      ssl_certificate_key /etc/nginx/certs/private.key;

      location / {
          proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
          proxy_set_header Host $http_host;
          proxy_pass http://172.16.0.3:8080;
          client_max_body_size 20000m;
      }
  }
  ```

  说明：proxy_pass http://172.16.0.3:8080需要替换为solo实际运行位置

## 配置mysql

* 进入mysql容器`docker exec -it mysql bash`
* 输入命令`mysql -u root -p`输入密码即可开始配置

使用 MySQL

手动建库（库名 `solo` ，字符集使用 `utf8mb4` ，排序规则 `utf8mb4_general_ci` ）：

```sql
create database solo default character set utf8mb4 collate utf8mb4_general_ci;
create user 'root'@'127.0.0.1' identified by '${PASSWD}';
grant all privileges on *.* to 'root'@'127.0.0.1';
flush privileges;
```

说明：${PASSWD}自行替换

## 构建solo容器

```bash
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD=${PASSWD} \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimez
one=UTC&allowPublicKeyRetrieval=true" \
    b3log/solo --listen_port=8080 --server_scheme=https --server_host=nanguomm.top --server_port=

```

访问80端口即可进入欢迎页面
