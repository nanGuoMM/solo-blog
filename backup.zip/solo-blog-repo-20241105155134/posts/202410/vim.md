title: vim
date: '2024-10-09 19:00:27'
updated: '2024-11-02 14:47:54'
tags: [linux]
permalink: /articles/2024/10/09/1728471627388.html
---
![image.png](https://b3logfile.com/file/2024/10/image-LMIpSpZ.png)

## 安装vim-plug

`curl -fLo ~/.vim/autoload/plug.vim --create-dirs https://raw.githubusercontent.com/junegunn/vim-plug/master/plug.vim`

## 安装nodejs npm

`pacman -S nodejs npm`

## 配置文件

`https://raw.githubusercontent.com/nanGuoMM/.dotfiles/refs/heads/master/tag-vim/vimrc`

vim命令模式执行PlugInstall

![image.png](https://b3logfile.com/file/2024/11/image-Z3JF69o.png)

进入~/.vim/plugged/coc.nvim执行

`npm ci`

这样就可以编译安装coc代码补全

![image.png](https://b3logfile.com/file/2024/11/image-4Cyn4oC.png)
