title: i3wm开发环境搭建
date: '2024-10-15 22:58:29'
updated: '2024-11-02 14:17:49'
tags: [linux]
permalink: /articles/2024/10/15/1729004308927.html
---
# 系统初始化

- 我用的opensuse服务器版本,他没有包含太多多余的东西
- 将普通用户加入wheel组赋予sudo

`usermod -aG wheel nanguo`

`visudo`

`su - nanguo`

# 连接网络

- opensuse自带networkmanager
  `nmtui`

# opi

- opi是一个包管理器,可以在社区查找其他包

`sudo zypper in opi`

# 字体

`opi nerd-fonts`

# xinit

- x11桌面环境启动器

`sudo zypper in xinit`

# i3wm

`sudo zypper in i3 i3blocks`

# 输入法

- suse自带fcix

# 必需软件

### alacritty

### maim & xclip

截图

https://nanguomm.top/articles/2024/10/09/1728489517372.html

# 可选

### vim

非常好用的编辑器

https://nanguomm.top/articles/2024/10/09/1728471627388.html

### redshift

护眼

https://nanguomm.top/articles/2024/10/09/1728473329659.html

### rsg

B站音频播放器

https://nanguomm.top/articles/2024/10/09/1728476037201.html

### thinkfan

thinkpad专用的风扇控制器

https://nanguomm.top/articles/2024/10/09/1728481864100.html
